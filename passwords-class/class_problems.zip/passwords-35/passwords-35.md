# Problem name (but without the above modifications)
Passwords 3.5
# Problem description
A friend told me that Java characters are actually two bytes, but what does that mean?
# Flag (camp{...} format)
camp{cmprs-evrythng-nd-mnmz-vwls-or-just-use-chinese??-3bgi}
# Point value (use pico scale, will be rebalanced later)
250
# Category
Reversing
# Hints
It may not look like it, but this problem is very similar to Passwords 2.5 and 3.0. Try solving all previous Passwords problems before this one.
# List of files the player should be allowed to download
Passwords35.java
# Any steps for deployment (compilation instructions, etc.)
Literally nothing, just upload the file. It doesn't even need to be ran.
# Your name!
Erez Israeli Miller
# Intended solvepath
Possible solve paths:
1. Literally just write the code in reverse
2. Just run the code, stick in the expected output in, and add a print statement
3. Manually XOR shift each character with ASCII

